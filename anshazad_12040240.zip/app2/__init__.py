import json
from flask import Flask, render_template, request, jsonify   

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("InputOutput.html")        

@app.route("/submitJSON", methods=["POST"])
def processJSON(): 
    jsonStr = request.get_json()
    jsonObj = json.loads(jsonStr)
    response=""
    age=int(jsonObj['age'])
    status=jsonObj['status']
    gender=jsonObj['gender']
    if (status == "married") :
        response+="<b> Driver is insured</b>"
    elif (gender== "male" and age > 30) or (gender== "female" and age > 25):
        response+="<b>Driver is insured</b>"
    else :
        response+="<b>Driver is not insured</b>"
    return response

