import json
from flask import Flask, render_template, request, jsonify   

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("InputOutput.html")        

@app.route("/submitJSON", methods=["POST"])
def processJSON(): 
    jsonStr = request.get_json()
    jsonObj = json.loads(jsonStr)
    response=""
    n=int(jsonObj['n'])
    
    if (year % 4) == 0:
     if (year % 100) == 0:
      if (year % 400) == 0:
        response+=('<b> "{0} is a leap year".format(year)) </b>'
      else:
        response+=('<b> "{0} is not a leap year".format(year)) </b>'
     else:
       response+=('<b> "{0} is a leap year".format(year)) </b>'
    else:
      response+=('<b> "{0} is not a leap year".format(year)) </b>'
    return response

